# Ideal Company

![Ideal Company](ideal-company-cover.png)

**ร่วมกันสร้างบริษัทในฝันของพวกเรา** เกมสำรวจความพึงพอใจในงาน 9 ด้าน ตามกรอบ Job Satisfaction Survey (JSS) ของ Spector

ผู้เล่นให้คะแนนความคาดหวังต่อบริษัทในฝัน 9 ด้าน ตอบคำถามเกี่ยวกับบริษัทจริง 45 ข้อ ดูช่องว่างระหว่างฝันกับความจริงบนตึก 9 ชั้น แล้วเสนอไอเดียพัฒนาองค์กร ผลส่งเข้า Google Sheets แบบไม่ระบุตัวตน ผู้วิจัยดูสถิติ บทความสรุปผล และดาวน์โหลดข้อมูลได้จากหน้า Admin

## ไฟล์ในโปรเจกต์

| ไฟล์ | หน้าที่ |
| --- | --- |
| `index.html` | ตัวเว็บทั้งหมด (ไฟล์เดียว) |
| `ideal-company-cover.png` | ภาพปกตอนแชร์ลิงก์ ขนาด 1200×630 |
| `apps-script/Code.gs` | ระบบเก็บผลใน Google Sheets |
| `.nojekyll` | ให้ GitHub Pages เสิร์ฟไฟล์ตามที่อัปโหลด |

## ติดตั้ง

### 1. ระบบเก็บผล (Google Sheets)

1. สร้าง Google Sheet ใหม่ แล้วเปิดเมนู **ส่วนขยาย → Apps Script**
2. วางโค้ดจาก `apps-script/Code.gs` แทนโค้ดเดิม แล้วบันทึก
3. ถ้าจะเปลี่ยนรหัสผู้ดูแล แก้ `const ADMIN_CODE = '240201041';`
4. **Deploy → New deployment → Web app** ตั้ง Execute as: **Me** และ Who has access: **Anyone**
5. อนุญาตสิทธิ์ แล้วคัดลอก Web app URL ที่ลงท้ายด้วย `/exec`

### 2. ใส่ URL ลงในเว็บ

แก้บรรทัดนี้ใน `index.html`

```js
const SITE_CONFIG={ENDPOINT:'https://script.google.com/macros/s/xxxx/exec'};
```

แก้บน GitHub ได้เลย: เปิดไฟล์ `index.html` → กดไอคอนดินสอ → ค้นหา `SITE_CONFIG` → แก้ → **Commit changes**

### 3. เปิดเว็บด้วย GitHub Pages

1. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ขึ้น repository (หน้า repo → **Add file → Upload files**)
2. ไปที่ **Settings → Pages**
3. Source: **Deploy from a branch** · Branch: **main** · Folder: **/ (root)** → **Save**
4. รอ 1–2 นาที เว็บจะอยู่ที่ `https://ชื่อผู้ใช้.github.io/ชื่อrepo/`

### 4. ภาพตอนแชร์ลิงก์

ใน `index.html` เปลี่ยน `ideal-company-cover.png` ใน 2 บรรทัด (`og:image` และ `twitter:image`) เป็นลิงก์เต็ม

```html
<meta property="og:image" content="https://ชื่อผู้ใช้.github.io/ชื่อrepo/ideal-company-cover.png">
```

ตรวจผลได้ที่ Facebook Sharing Debugger (developers.facebook.com/tools/debug)

### 5. ทดสอบ

1. เปิดเว็บแล้วเล่นจนจบ 1 รอบ
2. ใน Google Sheet แผ่น `responses` ต้องมีแถวใหม่
3. ที่หน้าแรกกด **Admin** ใส่รหัส แล้วดูผลในแท็บสถิติ

## หมายเหตุ

- ผู้เล่นไม่ต้องมีบัญชี ใครมีลิงก์ก็ส่งผลได้
- การอ่าน ดาวน์โหลด และลบข้อมูล ตรวจรหัสผู้ดูแลที่ฝั่ง Google ด้วย
- repository แบบ Public ทุกคนเห็นโค้ดได้ แต่ไม่เห็นข้อมูลผู้เล่น เพราะข้อมูลอยู่ใน Google Sheet ของคุณ ควรเปลี่ยน `ADMIN_CODE` ใน Apps Script ให้ต่างจากค่าตัวอย่าง แล้วแจ้งให้แก้รหัสในเว็บให้ตรงกัน
- ถ้าแก้ `Code.gs` ภายหลัง ให้ Deploy → Manage deployments → แก้ไข → Version: New version (URL เดิม)
- ถ้ายังไม่ใส่ URL เว็บยังเล่นได้ แต่ผู้เล่นจะได้ "รหัสผลลัพธ์" ไปส่งให้ผู้จัดแทน
