/**
 * Ideal Company – ระบบเก็บผลด้วย Google Sheets
 * วางโค้ดนี้ใน Apps Script ของ Google Sheet แล้ว Deploy เป็น Web App
 * (Execute as: Me, Who has access: Anyone)
 */

// รหัสผู้ดูแล ต้องตรงกับรหัสที่ใช้เข้าหน้า Admin ของเว็บ
const ADMIN_CODE = '240201041';
const SHEET_NAME = 'responses';
const MAX_BYTES = 20000;

const HEADERS = (function () {
  const h = ['id', 'saved_at', 'organization', 'age', 'status', 'company'];
  for (let i = 1; i <= 9; i++) h.push('ideal_' + i);
  for (let i = 1; i <= 45; i++) h.push('item_' + i);
  return h.concat(['ideas', 'extra', 'json']);
})();

function sheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);
  if (sh.getLastRow() === 0) {
    sh.appendRow(HEADERS);
    sh.setFrozenRows(1);
  }
  return sh;
}

function out_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function validId_(id) {
  return typeof id === 'string' && /^[A-Za-z0-9_\-]{3,80}$/.test(id);
}

function nums_(arr, len) {
  return Array.isArray(arr) && arr.length === len &&
    arr.every(function (v) { return v === Math.floor(v) && v >= 1 && v <= 5; });
}

function rowFor_(id, d) {
  const ideas = (d.ideas || []).map(function (i) {
    return '[ด้าน ' + (Number(i.d) + 1) + ' ' + (i.stars || 0) + '*] ' + String(i.text || '');
  }).join(' | ');
  return [id, new Date(), d.org || '', d.age || '', d.status || '', d.sim ? 'simulated' : 'real']
    .concat(d.ideal, d.items, [ideas, d.extra || '', JSON.stringify(d)]);
}

function doGet(e) {
  const p = (e && e.parameter) || {};
  if (p.action === 'list') {
    if (String(p.code || '') !== ADMIN_CODE) return out_({ ok: false, error: 'unauthorized' });
    const sh = sheet_();
    const last = sh.getLastRow();
    if (last < 2) return out_({ ok: true, rows: [] });
    const col = HEADERS.length;
    const values = sh.getRange(2, 1, last - 1, col).getValues();
    const rows = [];
    values.forEach(function (r) {
      try { rows.push({ id: String(r[0]), data: JSON.parse(r[col - 1]) }); } catch (err) {}
    });
    return out_({ ok: true, rows: rows });
  }
  return out_({ ok: true, service: 'ideal-company' });
}

function doPost(e) {
  const raw = (e && e.postData && e.postData.contents) || '';
  if (raw.length > MAX_BYTES) return out_({ ok: false, error: 'too_large' });
  let b;
  try { b = JSON.parse(raw); } catch (err) { return out_({ ok: false, error: 'bad_json' }); }

  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const sh = sheet_();
    const last = sh.getLastRow();
    const ids = last > 1 ? sh.getRange(2, 1, last - 1, 1).getValues().map(function (r) { return String(r[0]); }) : [];

    if (b.action === 'save') {
      const d = b.data || {};
      if (!validId_(b.id) || !nums_(d.ideal, 9) || !nums_(d.items, 45)) {
        return out_({ ok: false, error: 'invalid' });
      }
      const row = rowFor_(b.id, d);
      const at = ids.indexOf(b.id);
      if (at >= 0) sh.getRange(at + 2, 1, 1, row.length).setValues([row]);
      else sh.appendRow(row);
      return out_({ ok: true });
    }

    if (b.action === 'delete') {
      if (String(b.code || '') !== ADMIN_CODE) return out_({ ok: false, error: 'unauthorized' });
      const del = (b.ids || []).filter(validId_);
      let n = 0;
      for (let i = ids.length - 1; i >= 0; i--) {
        if (del.indexOf(ids[i]) >= 0) { sh.deleteRow(i + 2); n++; }
      }
      return out_({ ok: true, deleted: n });
    }

    return out_({ ok: false, error: 'unknown_action' });
  } finally {
    lock.releaseLock();
  }
}
